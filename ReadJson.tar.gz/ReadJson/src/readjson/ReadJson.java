/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package readjson;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import javax.net.ssl.HttpsURLConnection;
import org.json.*;

/**
 *
 * @author root
 */
public class ReadJson {
    public static void main(String[] args) throws Exception {
    String data="";
    
      File f=new File("/root/Desktop/shubham/ReadJson/src/readjson/test.json");
//  URL u=new URL("https://jsonplaceholder.typicode.com/users");
       // HttpsURLConnection  openConnection = (HttpsURLConnection) u.openConnection();
        FileInputStream in=new FileInputStream(f);
      // InputStream in = openConnection.getInputStream();
    int ch;
    while((ch=in.read())!=-1){
        data=data+(char)ch;
        System.out.println("hi");
    }
    
     try{
                JSONArray a=new JSONArray(data);
                for (int i=0;i<a.length();i++){
                    JSONObject o=a.getJSONObject(i);
                    String name = o.getString("name");
                    System.out.println(name);
                    JSONObject o2 = o.getJSONObject("address");
                    System.out.println(o2.getString("city"));
                }
            }
            catch(Exception e1){
               e1.printStackTrace();
            }
}
}

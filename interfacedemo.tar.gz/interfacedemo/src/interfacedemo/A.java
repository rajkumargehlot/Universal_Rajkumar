
package interfacedemo;


public interface A {
    void running();
    default void display()
    {
      System.out.println("hii i m interface A default method");
     }
    static void show()
    {
      System.out.println("hii i  m interface A static method");
    }
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfacedemo;

/**
 *
 * @author root
 */
public class B implements A {
    public void running()
    {
        System.out.println("Running.......");
    }
    public static void main(String[] args) {
        B obj=new B();
        obj.display();
        obj.running();
    }
    
}


package interfacedemo;

public class C {
    public static void main(String[] args) {
        A ref=new A(){
        @Override
        public void running()
        {
            System.out.println("Running.....");
        }
        };
        ref.running();
          }
    
}
